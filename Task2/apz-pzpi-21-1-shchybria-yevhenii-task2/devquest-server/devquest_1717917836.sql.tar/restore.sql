--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE devquest;
--
-- Name: devquest; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE devquest WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Ukrainian_Ukraine.1251';


ALTER DATABASE devquest OWNER TO postgres;

\connect devquest

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: achievements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.achievements (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    points integer NOT NULL,
    project_id uuid NOT NULL
);


ALTER TABLE public.achievements OWNER TO postgres;

--
-- Name: achievements_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.achievements_users (
    achievement_id uuid NOT NULL,
    developer_id uuid NOT NULL
);


ALTER TABLE public.achievements_users OWNER TO postgres;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    owner character varying(255),
    email character varying(255)
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    company_id uuid NOT NULL,
    manager_id uuid NOT NULL
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: projects_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects_users (
    project_id uuid NOT NULL,
    developer_id uuid NOT NULL,
    points integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.projects_users OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: task_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_categories (
    id uuid NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.task_categories OWNER TO postgres;

--
-- Name: task_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_statuses (
    id uuid NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.task_statuses OWNER TO postgres;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    expected_time timestamp without time zone NOT NULL,
    accepted_time timestamp without time zone,
    completed_time timestamp without time zone,
    category_id uuid NOT NULL,
    status_id uuid NOT NULL,
    project_id uuid NOT NULL,
    developer_id uuid,
    points integer NOT NULL
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role_id uuid NOT NULL,
    company_id uuid
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: achievements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.achievements (id, name, description, points, project_id) FROM stdin;
\.
COPY public.achievements (id, name, description, points, project_id) FROM '$$PATH$$/4845.dat';

--
-- Data for Name: achievements_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.achievements_users (achievement_id, developer_id) FROM stdin;
\.
COPY public.achievements_users (achievement_id, developer_id) FROM '$$PATH$$/4849.dat';

--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, owner, email) FROM stdin;
\.
COPY public.companies (id, name, owner, email) FROM '$$PATH$$/4843.dat';

--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, name, description, company_id, manager_id) FROM stdin;
\.
COPY public.projects (id, name, description, company_id, manager_id) FROM '$$PATH$$/4844.dat';

--
-- Data for Name: projects_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects_users (project_id, developer_id, points) FROM stdin;
\.
COPY public.projects_users (project_id, developer_id, points) FROM '$$PATH$$/4850.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, title) FROM stdin;
\.
COPY public.roles (id, title) FROM '$$PATH$$/4841.dat';

--
-- Data for Name: task_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_categories (id, name) FROM stdin;
\.
COPY public.task_categories (id, name) FROM '$$PATH$$/4846.dat';

--
-- Data for Name: task_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_statuses (id, name) FROM stdin;
\.
COPY public.task_statuses (id, name) FROM '$$PATH$$/4848.dat';

--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, name, description, expected_time, accepted_time, completed_time, category_id, status_id, project_id, developer_id, points) FROM stdin;
\.
COPY public.tasks (id, name, description, expected_time, accepted_time, completed_time, category_id, status_id, project_id, developer_id, points) FROM '$$PATH$$/4847.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, first_name, last_name, username, password_hash, role_id, company_id) FROM stdin;
\.
COPY public.users (id, first_name, last_name, username, password_hash, role_id, company_id) FROM '$$PATH$$/4842.dat';

--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (id);


--
-- Name: achievements_users achievements_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements_users
    ADD CONSTRAINT achievements_users_pkey PRIMARY KEY (achievement_id, developer_id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: projects_users projects_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects_users
    ADD CONSTRAINT projects_users_pkey PRIMARY KEY (project_id, developer_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: task_categories task_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_pkey PRIMARY KEY (id);


--
-- Name: task_statuses task_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_statuses
    ADD CONSTRAINT task_statuses_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: achievements_users achievements_users_achievements_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements_users
    ADD CONSTRAINT achievements_users_achievements_fk FOREIGN KEY (achievement_id) REFERENCES public.achievements(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: achievements_users achievements_users_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements_users
    ADD CONSTRAINT achievements_users_users_fk FOREIGN KEY (developer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_companies_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_companies_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: projects_users projects_users_projects_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects_users
    ADD CONSTRAINT projects_users_projects_fk FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects_users projects_users_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects_users
    ADD CONSTRAINT projects_users_users_fk FOREIGN KEY (developer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_task_categories_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_task_categories_fk FOREIGN KEY (category_id) REFERENCES public.task_categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: users users_companies_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_companies_fk FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_roles_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_roles_fk FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

